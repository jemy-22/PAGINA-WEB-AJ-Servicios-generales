# MultiplesJPanelEjemplo
El siguiente código muestra como trabajar con múltiples paneles con JAVA SWING, hacemos uso de dos botones(Siguiente y Atrás) para navegar entre los respectivos paneles
